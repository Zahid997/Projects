#!/usr/bin/python 

import sys
sys.path.append("src")
import unittest

from unittests import *
unittest.main()
